/*
 * pwm4.c
 *
 *  Created on: 5 Jan 2025 / reviewed Oct 2025
 *      Author: jayfox
 *
 *     Driver code is independ from sys_platform.h definitions
 *     Initialize the pwm-driver with the right address, or let it search for the address
 *
 *     Check pwm4.h for use details
 *
 */

#include "pwm4.h"
#include "reg_access.h"

uint32_t PWM4_ADDRESS =0;

// initialise base memory address to Global variable PWM4_ADDRES
// Or address is given (base<>0), or address is searched (base=0) at obvious locations
// RiscV Peripheral memory locations example 1 :0x00004000 (4K base mem) to 0x00042000 (256K base mem) in steps of 0x0400 (1K)
// RiscV Peripheral memory locations example 2 :0x40000000 (4K base mem) to 0x4000A400 (256K base mem) in steps of 0x0400 (1K)
uint32_t pwm4_init(uint32_t base)
{
	uint32_t t,d;
	if (base == 0x00000000) // trigger ID search
	{
		for(t=0x40000000; t<0x4000A000 ;t=t+0x00000400)  //ADAPT TO YOU MEMORY RANGE !!
		{
			reg_32b_read(t,	&d); // read Memory
			//printf("[0x%08X]=[0x%08X]\n", t,d );
			if ( d == PWM4_ID )
					{
					PWM4_ADDRESS=t; // found, store base address
					t = 0x4000A000; // end loop
					}
		}
		return(PWM4_ADDRESS);
	}
	else		// Address is given as input
	{
		PWM4_ADDRESS = base;
		return(PWM4_ADDRESS);
	}
}

// get Base address LocalMem Peripheral
uint32_t pwm4_getbase()
{
	return(PWM4_ADDRESS);
}

//read from pwm location into local register
uint8_t pwm4_getregister(uint8_t pwm,uint32_t *pwmregister)
{
uint32_t d,*pd;
pd = pwmregister;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	*pd=0;
	return(0);
	}
else
	{
	reg_32b_read((uint32_t) (PWM4_ADDRESS + pwm+1), &d );
	*pd=d;
	return(1);
	}
}


//read from pwm location into, get DC - lower 16 bits
uint8_t pwm4_getcycle(uint8_t pwm, uint16_t *dutycycle)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	*dutycycle=0;
	return(0);
	}
else
	{
	reg_32b_read(PWM4_ADDRESS + pwm+1 ,&reg ); // read register
	*dutycycle = (uint16_t) (0x0000FFFF&reg);  // lower 16 bits = DC
	return(1);
	}
}


//read from pwm location and write back: set/clear enable bit 16
uint8_t  pwm4_enable(uint8_t pwm, uint8_t logiclevel)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg_32b_read(PWM4_ADDRESS + pwm+1 ,&reg ); // read register
	if(logiclevel ==1) 	reg_32b_write(PWM4_ADDRESS + pwm+1 , reg| 0x00010000 );  // set bit 16
	else reg_32b_write(PWM4_ADDRESS + pwm+1 ,  reg & 0xFFFEFFFF); 				 // clear bit 16
	return(1);
	}
}

//read from pwm location and write beack: set/clear clear-bit 17
uint8_t  pwm4_clear(uint8_t pwm, uint8_t logiclevel)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg_32b_read(PWM4_ADDRESS + pwm+1 ,&reg ); // read register
	if(logiclevel ==1) 	reg_32b_write(PWM4_ADDRESS + pwm+1 , reg| 0x00020000 );  // set bit 17
	else reg_32b_write(PWM4_ADDRESS + pwm+1 ,  reg & 0xFFFDFFFF); 				 // clear bit 17
	return(1);
	}
}



//read from pwm location and write beack: set/clear clear-bit 17
uint8_t  pwm4_setcycle(uint8_t pwm,uint16_t dutycycle)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg_32b_read(PWM4_ADDRESS + pwm+1 ,&reg ); // read register
	reg_32b_write(PWM4_ADDRESS + pwm+1 ,   (reg & 0xFFFF0000) + dutycycle);  	// set bit 15:0 as duty cycle
	return(1);
	}
}





