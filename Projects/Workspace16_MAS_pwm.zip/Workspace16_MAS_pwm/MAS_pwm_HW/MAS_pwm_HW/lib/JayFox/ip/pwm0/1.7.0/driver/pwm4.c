/*
 * pwm4.c
 *
 *  Created on: 5 Jan 2025
 *      Author: jayfox
 */

#include "pwm4.h"


uint32_t PWM4_ADDRESS =0;

// initialise base memory address to Global variable PWM4_ADDRES
// Or address is given (base<>0), or address is searched (base=0) at obvious locations
// RiscV Peripheral memory locations :0x00004000 (4K base mem) to 0x00042000 (256K base mem) in steps of 0x0400 (1K)
uint32_t pwm4_init(uint32_t base)
{
	uint32_t t;
	if (base == 0x00000000) // trigger ID search
	{
		for(t=0x00004000; t<0x00042000 ;t=t+0x00000400)
		{
			if ( *((volatile uint32_t *)(t)) == PWM4_ID )
					{
					PWM4_ADDRESS=t; // found, store base address
					t = 0x00080000; // end loop
					}
		}
		return(PWM4_ADDRESS);
	}
	else		// Address is given as input
	{
		PWM4_ADDRESS = base;
		return(PWM4_ADDRESS);
	}
}

// get Base address LocalMem Peripheral
uint32_t pwm4_getbase()
{
	return(PWM4_ADDRESS);
}

//read from pwm location into local register
uint8_t pwm4_getregister(uint8_t pwm,uint32_t *pwmregister)
{
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	*pwmregister=0;
	return(0);
	}
else
	{
	*pwmregister = *((volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4));
	return(1);
	}
}


//read from pwm location into, get DC - lower 16 bits
uint8_t pwm4_getcycle(uint8_t pwm, uint16_t *dutycycle)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	*dutycycle=0;
	return(0);
	}
else
	{
	reg= *( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) );
	*dutycycle = (uint16_t) (0x0000FFFF&reg);
	return(1);
	}
}


//read from pwm location and write back: set/clear enable bit 16
uint8_t  pwm4_enable(uint8_t pwm, uint8_t logiclevel)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg= *( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ); 										// read PWM register
	if(logiclevel ==1) 	*( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) )= reg | 0x00010000;		// set bit 16
	else 	*( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ) = reg & 0xFFFEFFFF; 				// clear bit 16
	return(1);
	}
}

//read from pwm location and write beack: set/clear clear-bit 17
uint8_t  pwm4_clear(uint8_t pwm, uint8_t logiclevel)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg= *( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ); 										// read PWM register
	if(logiclevel ==1) 	*( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) )= reg | 0x00020000;		// set bit 17
	else 	*( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ) = reg & 0xFFFDFFFF; 				// clear bit 17
	return(1);
	}
}



//read from pwm location and write beack: set/clear clear-bit 17
uint8_t  pwm4_setcycle(uint8_t pwm,uint16_t dutycycle)
{
uint32_t reg;
if(pwm > MAXPWM || PWM4_ADDRESS==0)
	{
	return(0);
	}
else
	{
	reg= *( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ); 										// read PWM register
	*( (volatile uint32_t *)(PWM4_ADDRESS + (pwm+1)*4) ) = (reg & 0xFFFF0000) + dutycycle;  	// set bit 15:0 as duty cycle
	return(1);
	}
}





