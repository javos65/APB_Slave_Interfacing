/*
 * pwm4.h
 *
 *  Created on: 5 Jan 2025
 *      Author: jayFox
 */

#ifndef PWM4_H_
#define PWM4_H_

#include <stdint.h>
#include <stdbool.h>

#define PWM4_ID 0xB19B00B2 		// IP defined ID number in VHDL
#define MAXPWM 4		 	// MAX memory locations 0 to 4 -> Mapped to memory to =>  [BASE + 1 + LocationAddress]

#define PWM0	0
#define PWM1	1
#define PWM2	2
#define PWM3	3

uint32_t pwm4_init(uint32_t base);
uint8_t  pwm4_enable(uint8_t pwm,  uint8_t logiclevel);
uint8_t  pwm4_clear(uint8_t pwm,  uint8_t logiclevel);
uint8_t  pwm4_setcycle(uint8_t pwm,uint16_t dutycycle);
uint8_t pwm4_getcycle(uint8_t pwm, uint16_t *dutycycle);
uint8_t pwm4_getregister(uint8_t pwm, uint32_t *pwmregister);
uint32_t pwm4_getbase();

#endif /* PWM4_H_ */
